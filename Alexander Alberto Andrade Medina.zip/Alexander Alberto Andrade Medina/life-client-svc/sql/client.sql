create database life;

create schema client;

create table client.life_prd_product(
	prd_id serial primary key not null,
	prd_start_date date not null,
	prd_end_date date ,
	prd_limit float ,
	prd_available float ,
	prd_interest_rate float ,
	prd_interest_amount float, 
	prd_monthy_cur int ,
	prd_product_type varchar(1) not null,
	prd_create_date date not null default now(),
	prd_create_by varchar(20) not null default user,
	prd_modified_date date,
	prd_modified_by varchar(20)	

);
create table client.life_clt_client(
	clt_id serial primary key not null,
	clt_first_name varchar(50) not null,
	clt_last_name varchar(50) not null,
	clt_email varchar(100),
	clt_user_name varchar(50) not null,
	clt_password varchar(50) not null
);


create table client.life_pxc_product_x_client(
	pxc_id_client int not null,
	pxc_id_product int not null,
	pxc_product_type varchar(1) not null,
	constraint pxc_product_client_pk PRIMARY KEY  (pxc_id_product,pxc_id_client,pxc_product_type ),
	constraint pxc_client_fk foreign key (pxc_id_client) references client.life_clt_client(clt_id),
	constraint pxc_product_fk foreign key (pxc_id_product) references client.life_prd_product(prd_id),
	
);






insert into client.life_clt_client (clt_first_name,clt_last_name,clt_email,clt_user_name,clt_password) 
values('Alexander ','Andrade','alexander.andrade@hotmail.com','aandrade','12345');

insert into client.life_clt_client (clt_first_name,clt_last_name,clt_email,clt_user_name,clt_password) 
values('Ernesto','Andrade','chalke05@hotmail.com','eandrade','12345');

insert into client.life_clt_client (clt_first_name,clt_last_name,clt_email,clt_user_name,clt_password) 
values('Luz','Andrade','luzma05@hotmail.com','landrade','12345');

insert into client.life_prd_product (prd_start_date,prd_available,prd_product_type)
values ('2015-01-01',2800.00,'A');

insert into client.life_prd_product (prd_start_date,prd_available,prd_product_type)
values ('2019-01-01',2500.00,'A');

insert into client.life_pxc_product_x_client (pxc_id_client,pxc_id_product,pxc_product_type)
values (1,2,'A');

insert into client.life_pxc_product_x_client (pxc_id_client,pxc_id_product,pxc_product_type)
values (2,3,'A');

