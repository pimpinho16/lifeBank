package com.life.data;

import java.util.List;

public interface IProductData<T> {
	public T retrieveProductByClient(String clientCode) ;
	public Boolean isValidProduct(int idClient,int idProduct,String productType);
	public Boolean validAmount(int idProduct,Double amount);
	public Boolean accountTransfer(int originAccount, int destAccount,Double ammount,String productType);
	
	
	
}
