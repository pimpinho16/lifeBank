package com.life.repository;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.LifePrdProduct;
import com.life.entity.LifePxcProductXClient;

public interface ProductRepository extends CrudRepository<LifePrdProduct,LifePxcProductXClient>{
	public LifePrdProduct findByPrdId(int id);
}
