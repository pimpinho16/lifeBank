package com.life.pojo;

import java.util.List;

import com.life.pojo.svc.BankLoan;
import com.life.pojo.svc.CreditCard;

public class Product {
	Integer idClient ;
	List<Account> accounts;
	List<BankLoan> bankLoans;
	List<CreditCard> creditCards;


	public Integer getIdClient(){
		return idClient;
	}

	public void setIdClient(Integer idClient){
		this.idClient = idClient;

	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	public List<BankLoan> getBankLoans() {
		return bankLoans;
	}
	public void setBankLoans(List<BankLoan> bankLoans) {
		this.bankLoans = bankLoans;
	}
	public List<CreditCard> getCreditCards() {
		return creditCards;
	}
	public void setCreditCards(List<CreditCard> creditCards) {
		this.creditCards = creditCards;
	}
	
	
	

}
