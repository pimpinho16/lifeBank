package com.life.process;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.svc.Products;

public interface IProductProcess {
	public Envelope<Status,Products> retrieveProductsByClient(String idClient);
	public Envelope<Status,Boolean> isValidProductByClient(String idClient,String idProduct,String productType);
	public Envelope<Status,Boolean> debirCreditProcess(Transaction transaction);
}
