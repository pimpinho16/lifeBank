package com.life.pojo.svc;

import java.util.Date;

public class BankLoan {
	Integer id;
	String startDate;
	String endDate;
	Double deb;
	Double interestRate;
	Double interestAmount;
	
	public BankLoan(Integer id, String startDate, String endDate, Double deb, Double interestRate,
			Double interestAmount) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.deb = deb;
		this.interestRate = interestRate;
		this.interestAmount = interestAmount;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Double getDeb() {
		return deb;
	}
	public void setDeb(Double deb) {
		this.deb = deb;
	}
	public Double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}
	public Double getInterestAmount() {
		return interestAmount;
	}
	public void setInterestAmount(Double interestAmount) {
		this.interestAmount = interestAmount;
	}
	
	
	
	
	
}
