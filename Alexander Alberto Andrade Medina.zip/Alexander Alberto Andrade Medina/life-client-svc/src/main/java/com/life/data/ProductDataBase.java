package com.life.data;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.life.entity.LifePrdProduct;
import com.life.entity.LifePxcProductXClient;
import com.life.pojo.svc.Account;
import com.life.pojo.svc.BankLoan;
import com.life.pojo.svc.CreditCard;
import com.life.pojo.svc.Products;
import com.life.repository.ProductRepository;
import com.life.repository.ProductXClientRepository;

@Service("ProductDataBase")
public class ProductDataBase implements IProductData<Products>{
	private ProductRepository repoProduct;
	private ProductXClientRepository repoPxC;
	private Logger log;	
	
	@Value("${config.account}")
	String account;
	
	@Value("${config.loan}")
	String loan;
	
	@Value("${config.card}")
	String card;
	
	@Value("${config.date-format}")
	String format;
	
	public ProductDataBase(ProductRepository repoProduct,
		ProductXClientRepository repoPxC
		){
		this.repoProduct = repoProduct;
		this.repoPxC = repoPxC;
		this.log =  LoggerFactory.getLogger("com.life.logger");
	
	}


	@Override
	public Products retrieveProductByClient(String clientCode) {
		Products prods = null;
		List<Account> accounts = new ArrayList<>();
		List<CreditCard> creditCards = new ArrayList<>();
		List<BankLoan> bankLoans = new ArrayList<>();
		try{
			List<LifePxcProductXClient> pxc = repoPxC.findByIdPxcIdClient(Integer.parseInt(clientCode));
			if(!pxc.isEmpty()) {
				prods = new Products();
				prods.setIdClient(clientCode);
				SimpleDateFormat sdf = new  SimpleDateFormat(format);
				for(LifePxcProductXClient row: pxc) {
						LifePrdProduct op = repoProduct.findByPrdId(row.getId().getPxcIdProduct());
						
					
						if (op.getPrdProductType().equals(account)) {
							accounts.add(new Account(op.getPrdId(), 
									sdf.format(op.getPrdStartDate()),
									op.getPrdAvailable()
									));
							
						}else if (op.getPrdProductType().equals(loan)) {
							bankLoans.add(new BankLoan(op.getPrdId(),
									sdf.format(op.getPrdStartDate()),
									sdf.format(op.getPrdEndDate()),
									op.getPrdAvailable(),
									op.getPrdInterestRate(),
									op.getPrdInterestAmount()
									));
							
						}else if (op.getPrdProductType().equals(loan)) {
							creditCards.add(new CreditCard(op.getPrdId(), 
									sdf.format(op.getPrdStartDate()),
									sdf.format(op.getPrdEndDate()),
									op.getPrdLimit(),
									op.getPrdAvailable(),
									op.getPrdInterestRate(),
									op.getPrdMonthyCur()
									));
							
						}
						
					}
			}
					
		}catch(Exception ex){
			log.error("Error:" + ex.getMessage(),ex);
		}	
			prods.setAccounts(accounts);
			prods.setBankLoans(bankLoans);
			prods.setCreditCards(creditCards);
		
		return prods;
	}

@Override
	public Boolean isValidProduct(int idClient, int idProduct, String productType) {
		Boolean result = false;
		try{
			LifePxcProductXClient pxc = repoPxC.findByIdPxcIdClientAndIdPxcIdProductAndIdPxcProductType(idClient,idProduct,productType);
			if(pxc != null ){
				result = true;

			}
		}catch(Exception ex){
			log.error("Error isValidProduct:"+  ex.getMessage(),ex);


		}
		return result;
	}
	
@Override
	public Boolean validAmount(int idProduct,Double amount){
		Boolean result = false;
		try{
			LifePrdProduct prd = repoProduct.findByPrdId(idProduct);
			if(prd.getPrdAvailable()>=amount){
				result = true;
			}

		}catch(Exception ex){
			log.error("Error validAmount:"+  ex.getMessage(),ex);
		}
		return result;
	}

@Override
	public Boolean accountTransfer(int originAccount, int destAccount,Double ammount,String productType){
		Boolean result = false;
		try{
			LifePrdProduct prd = repoProduct.findByPrdId(originAccount);
			Double origin = prd.getPrdAvailable() - ammount;
			Double destiny = new Double();
			prd.setPrdAvalilable(origin);
			repoProduct.save(prd);
			prd = repoProduct.findByPrdId(destAccount);
			if(productType.equals(account)){
				destiny = prd.getPrdAvailable() + ammount;	
				prd.setPrdAvalilable(destiny);	
			}else if(productType.equals(load)){
				destiny = prd.getPrdAvailable() - ammount;
				prd.setPrdAvalilable(destiny);
			}else if(productType.equals(card)){
				destiny = prd.getPrdAvailable() + ammount;
				prd.setPrdAvalilable(destiny);
				destiny =  prd.getPrdLimit() - ammount;
				prd.setPrdLimit(destiny);
			}
			repoProduct.save(prd);
			result = true;
		}catch(Exception ex){
			log.error("Error accountTransfer:"+  ex.getMessage(),ex);
		}
		return result;
	}	

}
