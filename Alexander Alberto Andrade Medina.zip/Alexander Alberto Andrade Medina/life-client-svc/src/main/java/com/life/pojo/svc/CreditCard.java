package com.life.pojo.svc;

import java.util.Date;

public class CreditCard {
	Integer id;
	String startDate;
	String endDate;
	Double limit;
	Double available;
	Double interestRate;
	Integer monthlyCut;
	
	public CreditCard(Integer id, String startDate, String endDate, Double limit, Double available, Double interestRate,
			Integer monthlyCut) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.limit = limit;
		this.available = available;
		this.interestRate = interestRate;
		this.monthlyCut = monthlyCut;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Double getLimit() {
		return limit;
	}
	public void setLimit(Double limit) {
		this.limit = limit;
	}
	public Double getAvailable() {
		return available;
	}
	public void setAvailable(Double available) {
		this.available = available;
	}
	public Double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}
	public Integer getMonthlyCut() {
		return monthlyCut;
	}
	public void setMonthlyCut(Integer monthlyCut) {
		this.monthlyCut = monthlyCut;
	}
	
	
	

}
