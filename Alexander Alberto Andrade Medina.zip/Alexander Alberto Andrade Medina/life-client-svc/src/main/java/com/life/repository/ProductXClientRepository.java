package com.life.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.LifePrdProduct;
import com.life.entity.LifePxcProductXClient;
import com.life.entity.LifePxcProductXClientId;

public interface ProductXClientRepository extends CrudRepository<LifePxcProductXClient,LifePxcProductXClientId> {
	public List<LifePxcProductXClient> findByIdPxcIdClient(int idClient); 
	public LifePxcProductXClient findByIdPxcIdClientAndIdPxcIdProductAndIdPxcProductType(int idClient,int idProd,String productType);
	
}
