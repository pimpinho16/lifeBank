package com.life.process;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.life.data.IProductData;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Message;
import com.life.pojo.envelope.Status;
import com.life.pojo.svc.Products;
import com.life.utils.ResponseCode;
import com.life.utils.ResponseMsg;

@Service("ProductProcess")
public class ProductProcess implements IProductProcess{
	private IProductData<Products> data;
	
	
	
	private Environment env;
	private Logger log;

	@Value("${log-activator.activate}")
	String logFlag;
	

	public ProductProcess(
			@Qualifier("BeanDataProduct") IProductData<Products> data,
			Environment env) {
		this.data = data;		
		this.env = env;
		this.log =  LoggerFactory.getLogger("com.loyalty.logger");
	}
	
	
	@Override
	public Envelope<Status, Products> retrieveProductsByClient(String idClient) {
		Status s = new Status();
		Products products = new Products();
		if("true".equals(logFlag)){
			String g = "Start Retrieve Products by Client"; 
			log.info(g);
		}
		try{
			products = data.retrieveProductByClient(idClient);
			if(products !=null){
				s.setCode(ResponseCode.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);

			}else{
				s.setCode(ResponseCode.NOT_FOUND);
				s.setResult(ResponseMsg.NOT_FOUND);
			}

		}catch(Exception ex){
			s.setCode(ResponseCode.NOT_FOUND);
			s.setResult(ResponseMsg.NOT_FOUND);
			log.error("Error:" + ResponseMsg.NOT_FOUND,ex);
		}
		if("true".equals(logFlag)){
			String g = "End Retrieve Products by Client"; 
			log.info(g);
		}
		return new Message<>(s,products);
	}

	@Override
	public Envelope<Status,Boolean> isValidProductByClient(String idClient,String idProduct,String productType){
		Status s = new Status();
		Boolean result =false;
		if("true".equals(logFlag)){
			String g = "Start is Valid Products by Client Service"; 
			log.info(g);
		}
		try{
			result = data.isValidProduct(Integer.parseInt(idClient),Integer.parseInt(idProduct),productType);
			if(result){
				s.setCode(ResponseCode.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);
			}else{
				s.setCode(ResponseCode.NOT_FOUND);
				s.setResult(ResponseMsg.NOT_FOUND);
				log.error("Error:" + ResponseMsg.NOT_FOUND);
			}

		}catch(Exception ex){
			s.setCode(ResponseCode.NOT_FOUND);
			s.setResult(ResponseMsg.NOT_FOUND);
			log.error("Error:" + ResponseMsg.NOT_FOUND,ex);
		}
		return new Message<>(s,result);

	}


	@Override
	public Envelope<Status,Boolean> debitCreditProcess(Transaction transaction){
		Status s = new Status();
		Boolean result = false;
		try{
			if("true".equals(logFlag)){
				String g = "Start debitCreditProcess Service"; 
				log.info(g);
			}

			if(data.isValidProduct(transaction.getIdClient(), transaction.getOriginAccount(), 
				'A') && 
					(data.isValidProduct(transaction.getIdClient(), transaction.getDestAccount(), 
				'A')
				) ){
				if(data.validAmount(transaction.getOriginAccount(),transaction.getAmmount())){
					result =data.accountTransfer(transaction.getOriginAccount(),
												transaction.getDestAccount(),
												transaction.getAmmount(),
												transaction.getProductType());
					if(result){
						s.setCode(ResponseCode.SUCCESS);
						s.setResult(ResponseMsg.SUCCESS);				
					}else {
						s.setCode(ResponseCode.NOT_FOUND);
						s.setResult(ResponseMsg.NOT_FOUND);
					}

				}else{
					s.setCode(ResponseCode.NOT_ENOUGH);
					s.setResult(ResponseMsg.NOT_ENOUGH);
				}
			}else{
				s.setCode(ResponseCode.ERROR);
				s.setResult(ResponseMsg.ERROR);
			}
			if("true".equals(logFlag)){
				String g = "End debitCreditProcess Service"; 
				log.info(g);
			}

		}




	}
	

}
