package com.life.pojo.svc;

public class ProductXClient {

	private int idClient;
	private int idProduct;
	private String productType;
	
	
	
	public ProductXClient(int idClient, int idProduct, String productType) {
		super();
		this.idClient = idClient;
		this.idProduct = idProduct;
		this.productType = productType;
	}
	public int getIdClient() {
		return idClient;
	}
	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}
	public int getIdProduct() {
		return idProduct;
	}
	public void setIdProduct(int idProduct) {
		this.idProduct = idProduct;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	
	
	
	
}
