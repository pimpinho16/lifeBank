package com.life.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.svc.Products;
import com.life.process.IProductProcess;
import com.life.process.ProductProcess;
import com.life.utils.ResponseCode;

@RestController
public class ProductController {
	private IProductProcess process;

	public ProductController(ProductProcess process){
		this.process = process;
	}

	@GetMapping("${config.endpoints.product.get-products}")
	public ResponseEntity<?> getProductsByClient(
		@PathVariable("idClient") String idClient
		){
	 Envelope<Status,Products> result = process.retrieveProductsByClient(idClient);
	  if(	result.getHeader().getCode().equals(ResponseCode.SUCCESS)) {
			return new ResponseEntity<>(result, HttpStatus.OK);	
		}else return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);	
	}

	@GetMapping("${config.endpoints.product.is-valid-product}")
	public Envelope<Status,Boolean> isValidProduct(
		@PathVariable("idClient") String idClient,
		@PathVariable("idProduct") String idProduct,
		@PathVariable("productType") String productType
		){
		return process.isValidProductByClient(idClient,idProduct,productType);
	}
}
