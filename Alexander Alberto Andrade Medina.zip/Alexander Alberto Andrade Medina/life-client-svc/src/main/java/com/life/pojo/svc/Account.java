package com.life.pojo.svc;

import java.util.Date;

public class Account {
	Integer id;
	String startDate;
	Double amount;
	
	
	public Account(Integer id, String startDate, Double amount) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.amount = amount;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
}
