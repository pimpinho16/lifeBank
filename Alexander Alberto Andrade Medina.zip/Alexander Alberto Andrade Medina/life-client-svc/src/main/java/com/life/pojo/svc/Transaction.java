package com.life.svc;

public class Transaction{
	
	Integer originAccount;
	Integer destAccount;
	Integer clientId;
	Double ammount;
	String productType;

}