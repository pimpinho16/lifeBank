package com.life.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.life.pojo.svc.Account;
import com.life.pojo.svc.BankLoan;
import com.life.pojo.svc.CreditCard;
import com.life.pojo.svc.Products;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service("ProductStatic")
public class ProductStatic implements IProductData<Products>{

	private Products products;	
	private List<Account> accounts;
	private List<BankLoan> bankLoans;
	private List<CreditCard> creditCards;
	private Logger log;		
	
	public ProductStatic(){
		this.log = LoggerFactory.getLogger("com.loyalty.logger");
		creditCards = new ArrayList<>();
		bankLoans = new ArrayList<>();
		accounts = new ArrayList<>(); 
		products = new Products();
		creditCards.add(new CreditCard(10,"01-01-2019","01-01-2014",900.00,600.00,4.5,15));
		creditCards.add(new CreditCard(11,"01-01-2019","01-01-2014",900.00,600.00,4.5,15));
		bankLoans.add(new BankLoan(01,"01-10-2018","01-10-2024",5000.00,10.0,10.0));
		bankLoans.add(new BankLoan(02,"01-01-2015","01-01-2020",1000.00,10.0,10.0));
		accounts.add(new Account(04,"01-01-2015",700.00));
		products.setCreditCards(creditCards);
		products.setBankLoans(bankLoans);
		products.setAccounts(accounts);
		products.setIdClient("134567812");
		

	}

	@Override
	public Products retrieveProductByClient(String clientCode) {
		// TODO Auto-generated method stub
		log.info("Exito");
		return products;
	}

	@Override
	public Boolean isValidProduct(int idClient, int idProduct, String productType) {
		// TODO Auto-generated method stub
		return false;
	}



}
	