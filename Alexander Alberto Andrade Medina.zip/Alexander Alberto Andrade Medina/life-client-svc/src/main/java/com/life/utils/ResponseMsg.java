package com.life.utils;

public class ResponseMsg {
	public static final String SUCCESS="Success";
	public static final String NOT_FOUND="Not Found";
	public static final String NO_DATA="Error to call data layer";
	public static final String ERROR="Product info doesn't exists";
	public static final String NOT_ENOUGH="Not enough money";
}
