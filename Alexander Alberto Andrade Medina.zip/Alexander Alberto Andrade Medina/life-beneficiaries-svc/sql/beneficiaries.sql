create schema beneficiaries;


create  table beneficiaries.life_bnf_beneficiary(
	bnf_id serial  not null,
	bnf_client_id int not null,
	bnf_first_name varchar(100) not null,
	bnf_last_name varchar(100) not null,
	bnf_email varchar(100) not null,
	bnf_create_date date not null default now(),
	bnf_create_by varchar(50) not null default user,
	bnf_modified_date date,
	bnf_modify_by date,
	constraint bnf_benef_pk primary key (bnf_id)

);

create table client.life_bxc_benef_x_client(
	bxc_benef_id int not null,
	bxc_client_third_id int not null,
	bxc_product_id int not null,
	bxc_product_type varchar(1) not null,
	bxc_create_date date not null default now(),
	bxc_create_by varchar(50) not null default user,
	bxc_modified_date date,
	bxc_modify_by date, 
	constraint bxc_benef_x_client_pk primary key (bxc_benef_id,bxc_client_third_id,bxc_product_id,bxc_product_type)
);


