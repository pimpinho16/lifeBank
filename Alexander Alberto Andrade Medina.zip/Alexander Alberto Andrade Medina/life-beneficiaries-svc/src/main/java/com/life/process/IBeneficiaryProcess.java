package com.life.process;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.svc.Beneficiary;

public interface IBeneficiaryProcess {
	public Envelope<Status,Boolean> createBeneficiary(Beneficiary ben);
	public Envelope<Status, Boolean> modifyEmail(String benId,Beneficiary ben);
	public Envelope<Status, Boolean> deleteBeneficiary(String benId,Beneficiary ben);
}
