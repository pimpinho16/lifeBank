package com.life.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.svc.Beneficiary;
import com.life.process.BeneficiaryProcess;
import com.life.process.IBeneficiaryProcess;
import com.life.utils.ResponseCode;

@RestController
public class BeneficiaryController{
	private IBeneficiaryProcess process;

	public BeneficiaryController(BeneficiaryProcess process){
		this.process = process;	
	}
	
	@PostMapping("${config.endpoints.beneficiary.save-benef}")
	public ResponseEntity<?> saveBenef(
			@RequestBody Beneficiary input){
		Envelope<Status,Boolean> result = process.createBeneficiary(input);
		if(result.getHeader().getCode().equals(ResponseCode.BENEF_ERROR)){
			return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
		}else if(	result.getHeader().getCode().equals(ResponseCode.SUCCESS)) {
			return new ResponseEntity<>(result, HttpStatus.OK);	
		}else if(	result.getHeader().getCode().equals(ResponseCode.USR_NOT_EXISTS)) {
			return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);	
		}else return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);	

	}
	
	@PatchMapping("${config.endpoints.beneficiary.mod-email-benef}")
	public ResponseEntity<?> modifyEmail(
			@PathVariable(value="idBenef") String idBenef,
			@RequestBody Beneficiary input
			){
		Envelope<Status,Boolean> result = process.modifyEmail(idBenef,input);
		if(result.getHeader().getCode().equals(ResponseCode.BENEF_ERROR)){
			return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
		}else if(	result.getHeader().getCode().equals(ResponseCode.SUCCESS)) {
			return new ResponseEntity<>(result, HttpStatus.OK);	
		}else if(	result.getHeader().getCode().equals(ResponseCode.USR_NOT_EXISTS)) {
			return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);	
		}else return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);	

	}

	@DeleteMapping("${config.endpoints.beneficiary.del-benef}")
	public ResponseEntity<?> deleteBeneficiary(
		@PathVariable(value="idBenef") String idBenef,
		@RequestBody Beneficiary input){
		Envelope<Status,Boolean> result = process.deleteBeneficiary(idBenef,input);
		if(result.getHeader().getCode().equals(ResponseCode.BENEF_ERROR)){
			return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
		}else if(	result.getHeader().getCode().equals(ResponseCode.SUCCESS)) {
			return new ResponseEntity<>(result, HttpStatus.OK);	
		}else if(	result.getHeader().getCode().equals(ResponseCode.USR_NOT_EXISTS)) {
			return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);	
		}else return new ResponseEntity<>(result, HttpStatus.NOT_FOUND);	



	}

}




