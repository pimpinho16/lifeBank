package com.life.repository;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.LifeBxcBenefXClient;
import com.life.entity.LifeBxcBenefXClientId;

public interface BenefxClientRepository extends CrudRepository<LifeBxcBenefXClient,LifeBxcBenefXClientId>{
	public LifeBxcBenefXClient findByIdBxcClientThirdIdAndIdBxcClientId(int idThird,int idClient);
}
