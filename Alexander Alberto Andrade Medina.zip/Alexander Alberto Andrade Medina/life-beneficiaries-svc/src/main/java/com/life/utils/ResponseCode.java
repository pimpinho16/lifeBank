package com.life.utils;

public class ResponseCode {
	public static final String SUCCESS="200";
	public static final String NOT_FOUND="400";
	public static final String NO_DATA="401";
	public static final String USR_NOT_EXISTS="404";
	public static final String BENEF_ERROR="409";
}
