package com.life.data;

import com.life.pojo.svc.Beneficiary;

public interface IBeneficiaryData<T>{
	
	public Boolean createBeneficiary(Beneficiary ben);
	public Boolean isBeneficiary(Integer idThird,Integer idClient);
	public Boolean modifyEmail(String idBeneficiary, String email);
	public Boolean deleteBeneficiary(String idBeneficiary,Integer idThird,Integer idClient);
} 