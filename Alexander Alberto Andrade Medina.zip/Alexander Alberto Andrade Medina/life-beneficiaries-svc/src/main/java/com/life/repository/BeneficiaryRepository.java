package com.life.repository;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.LifeBnfBeneficiary;


public interface BeneficiaryRepository extends CrudRepository<LifeBnfBeneficiary, Integer>{
	
}
