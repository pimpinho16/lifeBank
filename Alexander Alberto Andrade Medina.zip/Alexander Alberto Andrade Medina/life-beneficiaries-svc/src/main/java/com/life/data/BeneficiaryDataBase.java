package com.life.data;

import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import com.life.data.productxclient.IProductxClientData;
import com.life.entity.LifeBnfBeneficiary;
import com.life.entity.LifeBxcBenefXClient;
import com.life.entity.LifeBxcBenefXClientId;
import com.life.pojo.svc.Beneficiary;
import com.life.repository.BeneficiaryRepository;
import com.life.repository.BenefxClientRepository;

@Service("BeneficiaryDataBase")
public class BeneficiaryDataBase implements IBeneficiaryData<Beneficiary>{
	
	private Logger log;	
	private BeneficiaryRepository benRepo;
	private BenefxClientRepository bxcRepo;
	



	public BeneficiaryDataBase(BeneficiaryRepository benRepo,
		BenefxClientRepository bxcRepo
		
		) {
		this.benRepo = benRepo;
		this.bxcRepo = bxcRepo;
	
		this.log =  LoggerFactory.getLogger("com.life.logger");
		
	}

	@Override
	public Boolean createBeneficiary(Beneficiary ben) {
		Boolean result = false;
		try{
			LifeBnfBeneficiary bnf = new LifeBnfBeneficiary();
			LifeBnfBeneficiary bnf2 = new LifeBnfBeneficiary();
			bnf.setBnfClientId(ben.getClientId());
			bnf.setBnfFirstName(ben.getFirstName());
			bnf.setBnfLastName(ben.getLastName());
			bnf.setBnfEmail(ben.getEmail());
			bnf.setBnfCreateDate(new Date());
			bnf.setBnfCreateBy("Life");
			bnf2 =   benRepo.save(bnf);
			
			
			
			LifeBxcBenefXClient bxc = new LifeBxcBenefXClient();
			LifeBxcBenefXClientId id = new LifeBxcBenefXClientId();
			id.setBxcBenefId(bnf2.getBnfId());
			id.setBxcClientThirdId(ben.getClientThirdId());
			id.setBxcClientId((ben.getClientId()));
			bxc.setBxcProductId(ben.getProductId());
			bxc.setBxcProductType(ben.getProductType());
			bxc.setBxcCreateDate(new Date());
			bxc.setBxcCreateBy("Life");
			
			bxc.setId(id);
			bxcRepo.save(bxc);
			result = true;
		}catch(Exception ex){
			log.error("Error:" +ex.getMessage(),ex);

		}
		return result;
	}

	@Override
	public Boolean modifyEmail(String idBeneficiary, String email) {
		Boolean result = false;
		try {
			Optional<LifeBnfBeneficiary> optional = benRepo.findById(Integer.parseInt(idBeneficiary));
			if(optional.isPresent()) {
				LifeBnfBeneficiary bnf = optional.get();
				bnf.setBnfEmail(email);
				benRepo.save(bnf);
				result = true;
			}
		}catch(Exception ex) {
			log.error("Error:" +ex.getMessage(),ex);
		}
		return result;
	}

	@Override
	public Boolean deleteBeneficiary(String idBeneficiary,Integer idThird,Integer idClient) {
		Boolean result = false;
		try{
			LifeBxcBenefXClientId bxc = new LifeBxcBenefXClientId(Integer.parseInt(idBeneficiary),idThird,idClient); 
			 if(bxcRepo.existsById(bxc)) {
				 bxcRepo.deleteById(bxc);
				 Optional<LifeBnfBeneficiary> optional = benRepo.findById(Integer.parseInt(idBeneficiary));
					if(optional != null) {
						if(optional.isPresent()) {
							LifeBnfBeneficiary bnf = optional.get();
							benRepo.delete(bnf);
							result = true;
						}
						
					}
			 }
			
		
		}catch(Exception ex){
			log.error("Error:" +ex.getMessage(),ex);
		}
		return result;
	}

	@Override
	public Boolean isBeneficiary(Integer idThird,Integer idClient){
		Boolean result = false;
		try{

			LifeBxcBenefXClient bxc = bxcRepo.findByIdBxcClientThirdIdAndIdBxcClientId( idThird, idClient);
			if(bxc!=null) result = true;
		} catch(Exception ex){
			log.error("Error:"+  ex.getMessage(),ex);

		}

		return result;
	}



}