package com.life.pojo.svc;

public class Beneficiary {
	
	
	Integer clientId;
	Integer productId;
	String productType;
	Integer clientThirdId;
	String email;
	String firstName;
	String lastName;
	
	
	
	public Beneficiary() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Beneficiary(Integer clientId, Integer productId, String productType, Integer clientThirdId, String email,
			String firstName, String lastName) {
		super();
		this.clientId = clientId;
		this.productId = productId;
		this.productType = productType;
		this.clientThirdId = clientThirdId;
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public Integer getClientId() {
		return clientId;
	}
	public void setClientId(Integer clientId) {
		this.clientId = clientId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Integer getClientThirdId() {
		return clientThirdId;
	}
	public void setClientThirdId(Integer clientThirdId) {
		this.clientThirdId = clientThirdId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	
	
	
	
}
