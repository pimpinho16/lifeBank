package com.life.process;

import com.life.data.IBeneficiaryData;
import com.life.data.productxclient.IProductxClientData;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Message;
import com.life.pojo.envelope.Status;
import com.life.pojo.svc.Beneficiary;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.life.utils.ResponseCode;
import com.life.utils.ResponseMsg;



@Service("BeneficiaryProcess")
public class BeneficiaryProcess implements IBeneficiaryProcess{
	private Environment env;
	private Logger log;		
	private IProductxClientData data;
	private IBeneficiaryData<Beneficiary> benData;


	@Value("${log-activator.activate}")
	String logFlag;

	
	public BeneficiaryProcess(@Qualifier("BeanDataProductxClient") IProductxClientData data,
		@Qualifier("BeanDataBeneficiary") IBeneficiaryData<Beneficiary> benData,
			Environment env
			) {
		this.env=env;
		 this.log =  LoggerFactory.getLogger("com.life.logger");
		 this.data = data;
		 this.benData = benData;
	}
	
	@Override
	public Envelope<Status, Boolean> createBeneficiary(Beneficiary ben) {
		Boolean result = false;
		Status s = new Status();
		try{
			
			if("true".equals(logFlag)){
				String g = "Start Save Beneficiary Process"; 
				log.info(g);
			}

			//validaciones
			Boolean isValid = data.isValidProductByClient(ben.getClientId().toString(),ben.getProductId().toString(),ben.getProductType());
			if(!isValid){
				s.setCode(ResponseCode.USR_NOT_EXISTS);
				s.setResult(ResponseMsg.USR_NOT_EXISTS);
			}else {
				if(!benData.isBeneficiary(ben.getClientThirdId(),ben.getClientId())){

					//validamos el correo
					String emailPattern = "^[_a-z0-9]+(\\.[_a-z0-9-]+)*@" +
						      "[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$";
					Pattern pattern = Pattern.compile(emailPattern);
					Matcher matcher  = pattern.matcher(ben.getEmail());
					if(matcher.matches()){


					
					result = benData.createBeneficiary(ben) ;
					if(result){
						//rama exitosa, el beneficiario se guardó
						s.setCode(ResponseCode.SUCCESS);
						s.setResult(ResponseMsg.SUCCESS);

					}else{
						//fallo por no poder guardar
						s.setCode(ResponseCode.NOT_FOUND);
						s.setResult(ResponseMsg.NOT_FOUND);				
					}
				}else {
					//fallo por ya ser beneficiario
					s.setCode(ResponseCode.BENEF_ERROR);
					s.setResult(ResponseMsg.BENEF_ERROR);	
				}
			}else{
				//fallo por correo erroneo
				s.setCode(ResponseCode.BENEF_ERROR);
				s.setResult(ResponseMsg.BENEF_ERROR);
			}
			}



			if("true".equals(logFlag)){
				String g = "End Save Beneficiary Process"; 
				log.info(g);
			}

		}catch(Exception ex){
			log.error("Error: " +ex.getMessage(),ex);
			s.setCode(ResponseCode.NOT_FOUND);
			s.setResult(ResponseMsg.NOT_FOUND);


		}
		return new Message<>(s,result);
	}

	@Override
	public Envelope<Status, Boolean> modifyEmail(String benId,Beneficiary ben) {
		Status s = new Status();
		Boolean result=false;
		try {
			if("true".equals(logFlag)){
				String g = "Start Modify Beneficiary Email Process"; 
				log.info(g);
			}
			if(benData.isBeneficiary(ben.getClientThirdId(),ben.getClientId())){
						//validamos el correo
					String emailPattern = "^[_a-z0-9]+(\\.[_a-z0-9-]+)*@" +
						      "[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$";
					Pattern pattern = Pattern.compile(emailPattern);
					Matcher matcher  = pattern.matcher(ben.getEmail());
					if(matcher.matches()){
				

						if(benData.modifyEmail(benId,ben.getEmail()))	{
							result = true;
							s.setCode(ResponseCode.SUCCESS);
							s.setResult(ResponseMsg.SUCCESS);
						}else{
							s.setCode(ResponseCode.BENEF_ERROR);
							s.setResult(ResponseMsg.BENEF_ERROR);
						}
					}else{
						s.setCode(ResponseCode.BENEF_ERROR);
						s.setResult(ResponseMsg.BENEF_ERROR);
					}
			
			}else{
				//no es beneficiario
				s.setCode(ResponseCode.USR_NOT_EXISTS);
				s.setResult(ResponseMsg.USR_NOT_EXISTS);
			}
			if("true".equals(logFlag)){
				String g = "End Modify Beneficiary Email Process"; 
				log.info(g);
			}
			
		}catch(Exception ex) {
			log.error("Error: " +ex.getMessage(),ex);
			s.setCode(ResponseCode.NOT_FOUND);
			s.setResult(ResponseMsg.NOT_FOUND);
		}
		
		return new Message<>(s,result);
	}

	@Override
	public Envelope<Status, Boolean> deleteBeneficiary(String benId,Beneficiary ben) {
		Status s = new Status();
		Boolean result = false;
		try{
			if("true".equals(logFlag)){
				String g = "Start Modify Beneficiary Email Process"; 
				log.info(g);
			}

			if(benData.isBeneficiary(ben.getClientThirdId(),ben.getClientId())){
				if(benData.deleteBeneficiary(benId,ben.getClientThirdId(),ben.getClientId())){
						s.setCode(ResponseCode.SUCCESS);
						s.setResult(ResponseMsg.SUCCESS);
						result = true;
				}else{
					log.error("Error: Delete not completed");
					s.setCode(ResponseCode.NOT_FOUND);
					s.setResult(ResponseMsg.NOT_FOUND);
				}
			}else{
				s.setCode(ResponseCode.USR_NOT_EXISTS);
				s.setResult(ResponseMsg.USR_NOT_EXISTS);
			}

			if("true".equals(logFlag)){
				String g = "End Modify Beneficiary Email Process"; 
				log.info(g);
			}
			
		}catch(Exception ex){
			log.error("Error:"+ex.getMessage(),ex);
			s.setCode(ResponseCode.NOT_FOUND);
			s.setResult(ResponseMsg.NOT_FOUND);

		}

		return new Message<>(s,result);
	}
	

}
