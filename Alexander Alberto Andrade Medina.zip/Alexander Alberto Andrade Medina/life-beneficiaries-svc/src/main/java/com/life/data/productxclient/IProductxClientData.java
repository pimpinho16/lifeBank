package com.life.data.productxclient;

public interface IProductxClientData {
	public Boolean isValidProductByClient(String idClient,String idProduct,String productType);
	

}
